class Section:
    def __init__(self):
        pass